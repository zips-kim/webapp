from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

# DB 객체 생성 (app.py에서 init_app으로 연결)
db = SQLAlchemy()

# ==========================================
# 1. 사용자 및 인증 관리
# ==========================================
class User(db.Model):
    """관리자, 모니터링 요원 등 시스템 사용자"""
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    login_id = db.Column(db.String(50), unique=True, nullable=False) # 로그인 ID
    password = db.Column(db.String(200), nullable=False) # 해시된 비밀번호
    role_level = db.Column(db.Integer, default=3) 
    # 1: 본부(Admin), 2: 모니터(View), 3: 현장(Staff)

    def __repr__(self):
        return f'<User {self.login_id}>'


# ==========================================
# 2. 시설 관리 (구호소, 집결지)
# ==========================================
class Shelter(db.Model):
    """이재민 대피소 (구호소)"""
    __tablename__ = 'shelters'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False) # 구호소명
    address = db.Column(db.String(200))
    phone = db.Column(db.String(20))
    area = db.Column(db.Integer)      # 면적
    capacity = db.Column(db.Integer)  # 수용 가능 인원
    is_active = db.Column(db.Boolean, default=True) # 운영 여부 (0/1 -> False/True)
    latitude = db.Column(db.Float)  # 위도 (예: 36.36...)
    longitude = db.Column(db.Float) # 경도 (예: 127.35...)

    # [관계 설정]
    # Shelter 삭제 시 관련 로그나 물품 처리 정책은 상황에 따라 cascade 설정 가능
    residents_logs = db.relationship('ResidentLog', backref='shelter', lazy=True)
    supplies = db.relationship('Supply', backref='shelter', lazy=True)
    duty_orders = db.relationship('DutyOrder', backref='shelter', lazy=True)
    staff_logs = db.relationship('StaffLog', backref='shelter', lazy=True)

    def __repr__(self):
        return f'<Shelter {self.name}>'


class AssemblyPoint(db.Model):
    """1차 집결지 (버스 정류장 등)"""
    __tablename__ = 'assembly_points'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    address = db.Column(db.String(200))
    stop_no = db.Column(db.String(50)) # 정류장 번호 등 식별자
    is_active = db.Column(db.Boolean, default=True)
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)

    # 집결지 -> 목적 구호소 (Many-to-Many)
    destinations = db.relationship('AssemblyDestination', backref='assembly_point', cascade="all, delete-orphan")


class AssemblyDestination(db.Model):
    """집결지와 구호소 간의 연결 테이블 (어느 집결지가 어느 구호소로 가는지)"""
    __tablename__ = 'assembly_destinations'

    id = db.Column(db.Integer, primary_key=True)
    assembly_id = db.Column(db.Integer, db.ForeignKey('assembly_points.id'), nullable=False)
    shelter_id = db.Column(db.Integer, db.ForeignKey('shelters.id'), nullable=False)
    
    waypoints = db.Column(db.Text, nullable=True)

    # 구호소 정보에 접근하기 위한 관계
    #assembly_point = db.relationship('AssemblyPoint', back_populates='destinations')
    target_shelter = db.relationship('Shelter', backref='assembly_sources')


# ==========================================
# 3. 이재민 관리
# ==========================================
class Resident(db.Model):
    """이재민 정보"""
    __tablename__ = 'residents'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    phone = db.Column(db.String(20))
    gender = db.Column(db.String(10)) # '남', '여'
    age = db.Column(db.String(10))    # 생년월일 또는 나이
    village = db.Column(db.String(100)) # 거주 마을
    
    family_id = db.Column(db.String(50)) # 가족 그룹 ID
    family_role = db.Column(db.String(20)) # '세대주', '세대원'
    
    note = db.Column(db.Text) # 특이사항 (지병 등)
    kakao_id = db.Column(db.String(100)) # 카카오 연동 ID

    # [관계 설정]
    logs = db.relationship('ResidentLog', backref='resident', lazy=True, cascade="all, delete-orphan")
    distributions = db.relationship('DistributionLog', backref='resident', lazy=True)

    def __repr__(self):
        return f'<Resident {self.name}>'


class ResidentLog(db.Model):
    """이재민 상태 변경 이력 (입소/퇴소/병원이송)"""
    __tablename__ = 'resident_logs'

    id = db.Column(db.Integer, primary_key=True)
    resident_id = db.Column(db.Integer, db.ForeignKey('residents.id'), nullable=False)
    shelter_id = db.Column(db.Integer, db.ForeignKey('shelters.id'), nullable=False)
    
    status = db.Column(db.String(20), nullable=False) # IN, OUT, HOSPITAL
    log_time = db.Column(db.DateTime, default=datetime.now) # 상태 변경 시간


# ==========================================
# 4. 구호물품 관리
# ==========================================
class Supply(db.Model):
    """구호물품 재고"""
    __tablename__ = 'supplies'

    id = db.Column(db.Integer, primary_key=True)
    # shelter_id가 NULL이면 '본부(HQ)' 재고임
    shelter_id = db.Column(db.Integer, db.ForeignKey('shelters.id'), nullable=True)
    item_name = db.Column(db.String(100), nullable=False)
    quantity = db.Column(db.Integer, default=0)

    # 물품 지급/이동 이력 관계
    distributions = db.relationship('DistributionLog', backref='supply', lazy=True)

    def __repr__(self):
        loc = self.shelter.name if self.shelter else "본부"
        return f'<Supply {self.item_name} ({loc}: {self.quantity})>'


class DistributionLog(db.Model):
    """이재민 개개인에게 지급된 물품 기록"""
    __tablename__ = 'distribution_logs'

    id = db.Column(db.Integer, primary_key=True)
    resident_id = db.Column(db.Integer, db.ForeignKey('residents.id'), nullable=False)
    supply_id = db.Column(db.Integer, db.ForeignKey('supplies.id'), nullable=False)
    quantity = db.Column(db.Integer, default=1)
    distributed_at = db.Column(db.DateTime, default=datetime.now)


class SupplyMovementLog(db.Model):
    """본부 -> 구호소 물품 배분(이동) 이력"""
    __tablename__ = 'supply_movement_logs'

    id = db.Column(db.Integer, primary_key=True)
    item_name = db.Column(db.String(100), nullable=False)
    to_shelter_id = db.Column(db.Integer, db.ForeignKey('shelters.id'), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    moved_at = db.Column(db.DateTime, default=datetime.now)
    staff_name = db.Column(db.String(50)) # 처리한 담당자 이름


# ==========================================
# 5. 근무자 및 근무 명령 관리
# ==========================================
class DutyOrder(db.Model):
    """사전 근무 명령서 (Admin이 생성)"""
    __tablename__ = 'duty_orders'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(50), nullable=False)
    dept = db.Column(db.String(50))  # 소속 부서
    phone = db.Column(db.String(20))
    mission = db.Column(db.String(100)) # 담당 임무
    shelter_id = db.Column(db.Integer, db.ForeignKey('shelters.id'), nullable=False)
    is_working = db.Column(db.Boolean, default=False) # 현재 근무 시작 여부


class StaffLog(db.Model):
    """실제 근무 이력 (출근~퇴근 로그)"""
    __tablename__ = 'staff_logs'

    id = db.Column(db.Integer, primary_key=True)
    user_name = db.Column(db.String(50), nullable=False)
    user_phone = db.Column(db.String(20))
    dept = db.Column(db.String(50))
    mission = db.Column(db.String(100))
    shelter_id = db.Column(db.Integer, db.ForeignKey('shelters.id'), nullable=False)
    
    login_time = db.Column(db.DateTime, default=datetime.now) # 근무 시작
    logout_time = db.Column(db.DateTime, nullable=True)       # 근무 종료 (NULL이면 근무 중)